-- MySQL dump 10.13  Distrib 8.0.24, for Win64 (x86_64)
--
-- Host: localhost    Database: maxtenant
-- ------------------------------------------------------
-- Server version	5.7.34-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tenant`
--

DROP TABLE IF EXISTS `tenant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tenant` (
  `TenantId` varchar(50) COLLATE utf8_bin NOT NULL,
  `OrganizationName` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `OrganizationId` int(11) NOT NULL,
  `DatabaseName` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `HostName` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `ConnectionString` varchar(500) COLLATE utf8_bin DEFAULT NULL,
  `APIKey` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `SecretKey` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `BaseUrl` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `SenderEmailAddress` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `EmailServer` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `EmailSenderUserName` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `EmailSenderPassword` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `EmailServerPort` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `EmailServerNeedsAuthentication` int(11) DEFAULT NULL,
  `StorageConnectionString` varchar(1000) COLLATE utf8_bin DEFAULT NULL,
  `SolrUrl` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `SociableBaseUrl` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `SociableAdminUserName` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `SociableAdminPassword` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `VerificationMinutes` double DEFAULT '5',
  PRIMARY KEY (`TenantId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tenant`
--

LOCK TABLES `tenant` WRITE;
/*!40000 ALTER TABLE `tenant` DISABLE KEYS */;
INSERT INTO `tenant` VALUES ('0571ef71-ea60-11ed-b04d-38f3ab158646','ncacc-demo',1,'ncacc-demo','maxapi','server=localhost;port=3306;database=ncacc-demo;uid=root;password=Anit1066','','','https://lightingbolt.azurewebsites.net/','support@membermax.com','secure.emailsrvr.com','support@membermax.com','bind-sinker-MAX-snapshot','465',1,NULL,NULL,NULL,NULL,NULL,5),('13364322-0574-11ec-8bc5-38f3ab158646','membermax',1,'membermax','maxapi','server=localhost;port=3306;database=membermax;uid=root;password=Anit1066',NULL,NULL,'https://trilixqa.membermax.com/','support@membermax.com','secure.emailsrvr.com','support@membermax.com','bind-sinker-MAX-snapshot','465',1,NULL,NULL,'','administrator','dK994owatSvH43MwrJte',5),('2076fffc-d2c4-11ec-b2c9-000d3a9cff9d','sales-demo',1,'trilix_demo','maxapi','server=localhost;port=3306;database=trilix_demo;uid=root;password=Anit1066','','','https://trilixqa.membermax.com/','support@membermax.com','secure.emailsrvr.com','support@membermax.com','bind-sinker-MAX-snapshot','465',1,'DefaultEndpointsProtocol=https;AccountName=trilixnbmadoc;AccountKey=eFuF92fjQ25sw2sOJ2/Kvyih+fXUylTFcmnYTlnWO9gOUqTiopw2d1QfIUEITRUk66ysXHWSfZ37+ASt1t0dqw==;EndpointSuffix=core.windows.net',NULL,'','administrator','dK994owatSvH43MwrJte',5),('69f8ee11-e19f-11ec-b864-000d3a9cff9d','sbe',1,'max_sbe','maxapi','server=localhost;port=3306;database=max_sbe;uid=root;password=Anit1066','','','https://trilixqa.membermax.com/','support@membermax.com','secure.emailsrvr.com','support@membermax.com','bind-sinker-MAX-snapshot','465',1,NULL,NULL,'','administrator','dK994owatSvH43MwrJte',5),('8dc124c6-8c00-11ed-95ec-000d3a9cff9d','usccb',1,'max_uccb_old','maxapi','server=localhost;port=3306;database=max_uccb_old;uid=root;password=Anit1066','','','https://trilixqa.membermax.com/','support@membermax.com','secure.emailsrvr.com','support@membermax.com','bind-sinker-MAX-snapshot','465',1,'DefaultEndpointsProtocol=https;AccountName=maxdocbishop;AccountKey=X/M7pLaRMlqcmAnFNHbrs3A+CJmYbmBSSv8wUEw6kpkjeXljeZ8l0E9k/b+ltWqt61xWV2cF5NPI+AStBo6zuw==;EndpointSuffix=core.windows.net',NULL,NULL,NULL,NULL,5),('9e30be6b-83f9-11ec-a99c-000d3a9cff9d','nbma-demo',1,'nbma-demo','maxapi','server=localhost;port=3306;database=nbma-demo;uid=root;password=Anit1066',NULL,NULL,'https://trilixqa.membermax.com/','support@membermax.com','secure.emailsrvr.com','support@membermax.com','bind-sinker-MAX-snapshot','465',1,'DefaultEndpointsProtocol=https;AccountName=trilixnbmadoc;AccountKey=eFuF92fjQ25sw2sOJ2/Kvyih+fXUylTFcmnYTlnWO9gOUqTiopw2d1QfIUEITRUk66ysXHWSfZ37+ASt1t0dqw==;EndpointSuffix=core.windows.net',NULL,'https://trilix-members-qa.membermax.com','administrator','dK994owatSvH43MwrJte',5),('f1708e19-f922-11ec-af6a-000d3a9cff9d','bishop-demo',1,'trilix_bishop','maxapi','server=localhost;port=3306;database=trilix_bishop;uid=root;password=Anit1066','','','https://trilixqa.membermax.com/','support@membermax.com','secure.emailsrvr.com','support@membermax.com','bind-sinker-MAX-snapshot','465',1,'DefaultEndpointsProtocol=https;AccountName=maxdocbishop;AccountKey=X/M7pLaRMlqcmAnFNHbrs3A+CJmYbmBSSv8wUEw6kpkjeXljeZ8l0E9k/b+ltWqt61xWV2cF5NPI+AStBo6zuw==;EndpointSuffix=core.windows.net',NULL,'https://trilix-social.membermax.com','administrator','dK994owatSvH43MwrJte',20);
/*!40000 ALTER TABLE `tenant` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-10  4:49:30
