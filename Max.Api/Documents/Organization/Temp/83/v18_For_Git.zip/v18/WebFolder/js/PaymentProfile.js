var token = "";
var baseUrl = "";
var strHTML = "";
var strBankHTML = "";
var PreferredPayId = "";
var preferredProfileFound = false;

$(function () {  
  var objProfileDetail = $("#divProfileDetails");
  var objDivLoading = $("#divLoading");
  var objResponse;

  objDivLoading.show();

  objResponse = $("#response").val();
    if (objResponse.length > 0) {
      objDivLoading.hide();
      var objParseResponse = JSON.parse(objResponse);
      var objPaymentProfileArray = [];
      var isBankAccountHeader = true;
      var isCreditCardHeader = true;      

      objPaymentProfileArray = objParseResponse.profile.paymentProfiles;
      if (objPaymentProfileArray != null) {
        if (objPaymentProfileArray.length > 0) {

        $(objPaymentProfileArray).each(function (index, item) {
          if (item.payment.bankAccount != null) {
            if (isBankAccountHeader) {
              strBankHTML += GenerateBankAccountHeader();
              isBankAccountHeader = false;
            }
            strBankHTML += GenerateBankAccountRow(item, index);
            //objTblbankAccount.html(strBankHTML);
          } else if (item.payment.creditCard != null) {
            if (isCreditCardHeader) {
              strHTML += GenerateCreditCardHeader();
              isCreditCardHeader = false;
            }
            strHTML += GenerateCreditCardRow(item, index);
            //objTblCCDetail.html(strHTML);
          }
        });
        if (strBankHTML.length > 0) {
          strBankHTML += GenerateBankAccountTableEndTag();
        }
        if (strHTML.length > 0) {
          strHTML += GenerateCreditCardTableEndTag();
        }
        objProfileDetail.show();
        //objProfileDetail.html(strHTML);
        if (strBankHTML.length > 0 && strHTML.length > 0) {
          $("#divBlank").show();
        }
        if (strBankHTML.length > 0) {
          $("#divBankAccountDetail").html(strBankHTML);
          $("#divBankAccountDetail").show();
        }
        if (strHTML.length > 0) {
          $("#divCCDetail").html(strHTML);
          $("#divCCDetail").show();
        }
      }
    } 
  }   
});

function GenerateBlankRow() {
  var strRow = "";
  strRow += "<tr>";
  strRow += "<td colspan='4' style='height:50px;'></td>";
  strRow += "<tr>";
  return strRow;
}

function GenerateBankAccountRow(item, index) {
  var strRow = "";
  strRow += "<tr>";
  if ($("#preferredPayId").val() == item.customerPaymentProfileId) {
    preferredProfileFound=true;
    strRow +=
      "<td align='center'><input type='radio' id='radioPaymentProfile_" + index +"' name='chkSelectedPaymentProfile' value='" + item.customerPaymentProfileId + "' class='with-font' checked='checked' />";
  } else {
    strRow +=
      "<td align='center'><input type='radio' id='radioPaymentProfile_" + index +"' name='chkSelectedPaymentProfile' value='" + item.customerPaymentProfileId + "' class='with-font' />";
  }
  strRow +=
    "<td align='center'>" + item.payment.bankAccount.accountNumber + "</td>";
  strRow +=
    "<td align='center'>" + item.payment.bankAccount.routingNumber + "</td>";
  strRow +=
    "<td align='center'>" +
    item.payment.bankAccount.accountType.charAt(0).toUpperCase() +
    item.payment.bankAccount.accountType.substr(1).toLowerCase() +
    "</td>";
  

  strRow += "</tr>";
  return strRow;
}

function GenerateCreditCardRow(item, index) {
  var strRow = "";
  strRow += "<tr>";
 if ($("#preferredPayId").val() == item.customerPaymentProfileId) {
    preferredProfileFound=true;
    strRow +=
      "<td align='center'><input type='radio' id='radioPaymentProfile_" + index +"' name='chkSelectedPaymentProfile' value='" + item.customerPaymentProfileId + "' class='with-font' checked='checked' />";
  } else {
    strRow +=
      "<td align='center'><input type='radio' id='radioPaymentProfile_" + index +"' name='chkSelectedPaymentProfile' value='" + item.customerPaymentProfileId + "' class='with-font' />";
  }

  strRow += "<td align='center'>" + item.payment.creditCard.cardNumber + "</td>";
  strRow += "<td align='center'>" + item.payment.creditCard.expirationDate + "</td>";
  strRow += "<td align='center'>" + GetFormatedCardNumber(item.payment.creditCard.cardType) + "</td>";  
  strRow += "</tr>";

  return strRow;
}

function GenerateBankAccountHeader() {
  var strRow = "";
  strRow += "<table id='tblBankAccount' cellpadding='10' cellspacing='20' border='0' width='100%'>";
  strRow += "<tr height='10px'>";
  strRow +=
    "<td width='10%' align='center'>&nbsp;</td><td width='30%' align='center'><b>Account Number</b></td><td width='30%' align='center'><b>Routing Number</b></td><td width='30%' align='center'><b>Account Type</b></td>";
  strRow += "</tr>";
  return strRow;
}

function GenerateCreditCardHeader() {
  var strRow = "";
  strRow += "<table id='tblCreditCard cellpadding='10' cellspacing='20' border='0' width='100%'>";
  strRow += "<tr height='10px'>";
  strRow +=
    "<td width='10%' align='center'>&nbsp;</td><td width='30%' align='center'><b>Card Number</b></td><td width='30%' align='center'><b>Expiration Date</b></td><td width='30%' align='center'><b>Card Type</b></td>";
  strRow += "</tr>";
  return strRow;
}

function GenerateCreditCardTableEndTag() {
  var strRow = "";
  strRow += "</table>";
  return strRow;
}

function GenerateBankAccountTableEndTag() {
  var strRow = "";
  strRow += "</table>";
  return strRow;
}

function GetFormatedCardNumber(cardTypeToFormat) {
  var cardType = "";
  switch (cardTypeToFormat) {
    case "Visa":
      cardType = "Visa";
      break;
    case "AmericanExpress":
      cardType = "American Express";
      break;
    case "MasterCard":
      cardType = "Master Card";
      break;
    case "Discover":
      cardType = "Discover";
      break;
    case "JCB":
      cardType = "JCB";
      break;
    case "DinersClub":
      cardType = "Diners Club";
      break;
    default:
      cardType = "NA";
  }
  return cardType;
}



///////////////////////////////////Validation Code\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\


function showPaymentMethod() {
var inputPay = document.getElementById('inputPay');
  if (inputPay.value=="5") {
    document.getElementById('divPersonPaymentProfile').setAttribute("class", "mbrmax-d-block");
    var hasSavedPaymentProfile = document.getElementById("paymentProfileExist").value;
    if(hasSavedPaymentProfile=="0")
    {
      document.getElementById('divInfoMessage').setAttribute("class", "mbrmax-d-block alert alert-info");
      document.getElementById('divErrorMessage').setAttribute("class", "mbrmax-d-none");
      document.getElementById('divSavedPayment').setAttribute("class", "mbrmax-col-md-6  mbrmax-rounded-div");
    }        
    else 
    { 
      document.getElementById('divSavedPayment').setAttribute("class", "mbrmax-col-md-6  mbrmax-rounded-div");
      document.getElementById('divErrorMessage').setAttribute("class", "mbrmax-d-none");
      // document.getElementById('divInfoMessage').setAttribute("class", "mbrmax-d-none");
    } 
  } 
  else {
    document.getElementById('divPersonPaymentProfile').setAttribute("class", "mbrmax-d-none");
  }
}

// below function was validating the checkbox selection of payment profiles, but changed it to radio button so valiations not required

function validateSavedPaymentMethod() {
  if(document.getElementById('inputPay').value==5) {
    var hasSavedPaymentProfile = document.getElementById("paymentProfileExist").value;
    if(hasSavedPaymentProfile=="0")
    {
      document.getElementById('divInfoMessage').setAttribute("class", "mbrmax-d-none");
      document.getElementById('divSavedPayment').setAttribute("class", "mbrmax-col-md-6  select-payment-validation");
      document.getElementById('divErrorMessage').setAttribute("class", "mbrmax-d-block  alert alert-danger");
      document.getElementById('divErrorMessage').innerText = "OOPS! You do not have any payment method(s) saved.";
      return false;
    }        
    else 
    { 
      document.getElementById('divSavedPayment').setAttribute("class", "mbrmax-col-md-6  mbrmax-rounded-div");
      document.getElementById('divErrorMessage').setAttribute("class", "mbrmax-d-none");
      document.getElementById('divInfoMessage').setAttribute("class", "mbrmax-d-none");
      return true;  
    }
    // var checkboxes = document.getElementsByName("chkSelectedPaymentProfile");  
    // var numberOfCheckedItems = 0;
    // for(var i = 0; i < checkboxes.length; i++)  
    // {  
    //     if(checkboxes[i].checked)  
    //         numberOfCheckedItems++;  
    // }  
    // if(hasSavedPaymentProfile=="1")
    // {
    //   if(numberOfCheckedItems > 1)  
    //   { 
    //       document.getElementById('divSavedPayment').setAttribute("class", "mbrmax-col-md-6  select-payment-validation"); 
    //       document.getElementById('divErrorMessage').setAttribute("class", "mbrmax-d-block  alert alert-danger");
    //       document.getElementById('divErrorMessage').innerText = "You can select only one payment method." 
    //       return false;  
    //   }
    //   else if(numberOfCheckedItems==0)  
    //   { 
    //       document.getElementById('divSavedPayment').setAttribute("class", "mbrmax-col-md-6  select-payment-validation");
    //       document.getElementById('divErrorMessage').setAttribute("class", "mbrmax-d-block  alert alert-danger");
    //       document.getElementById('divErrorMessage').innerText = "Please select atleast one payment method." 
    //       return false;  
    //   }
    // }
            
  }
}


