var token = "";
var baseUrl = "";
var strHTML = "";
var strBankHTML = "";
var PreferredPayId = "";

// function $(id) {
//   return document.getElementById(id);
// }

$(function () {
  var objProfileDetail = $("#divProfileDetails");
  var objIFrame = $("#divIframe");
  var objDivLoading = $("#divLoading");
  var objErrorDesc = $("#errorMsg");
  var objResponse;

  $("#divFieldSetBankAccount").hide();
  $("#divFieldSetCreditCard").hide();

  objDivLoading.show();
  baseUrl = $("#baseUrl").val();
  objResponse = $("#response").val();
  if (objErrorDesc.val().length == 0) {
    if (objResponse.length > 0) {
      var objParseResponse = JSON.parse(objResponse);
      var objPaymentProfileArray = [];
      var isBankAccountHeader = true;
      var isCreditCardHeader = true;
      var isInsertBlankRow = false;

      objPaymentProfileArray = objParseResponse.profile.paymentProfiles;
      if (objPaymentProfileArray != null) {
        if (objPaymentProfileArray.length > 0) {
          //strHTML += "<table id='tblSearchCorePrograms' class='list-table' width='100%' border='0'>";
          $(objPaymentProfileArray).each(function (index, item) {
            if (item.payment.bankAccount != null) {
              if (isBankAccountHeader) {
                strBankHTML += GenerateBankAccountHeader();
                isBankAccountHeader = false;
              }
              strBankHTML += GenerateBankAccountRow(item, index);
              //objTblbankAccount.html(strBankHTML);
            } else if (item.payment.creditCard != null) {
              if (isCreditCardHeader) {
                strHTML += GenerateCreditCardHeader();
                isCreditCardHeader = false;
              }
              strHTML += GenerateCreditCardRow(item, index);
              //objTblCCDetail.html(strHTML);
            }
          });
          if (strBankHTML.length > 0) {
            strBankHTML += GenerateBankAccountTableEndTag();
          }
          if (strHTML.length > 0) {
            strHTML += GenerateCreditCardTableEndTag();
          }
          objProfileDetail.show();
          //objProfileDetail.html(strHTML);
          if (strBankHTML.length > 0 && strHTML.length > 0) {
            $("#divBlank").show();
          }
          if (strBankHTML.length > 0) {
            $("#divBankAccountDetail").html(strBankHTML);
            $("#divFieldSetBankAccount").show();
          }
          if (strHTML.length > 0) {
            $("#divCCDetail").html(strHTML);
            $("#divFieldSetCreditCard").show();
          }
          objIFrame.hide();
          objDivLoading.hide();
          $("#divInfoAlert").hide();
          $("#divErrorInfo").hide();
        } else {
          $("#divInfoAlert").show();
          objDivLoading.hide();
          $("#divErrorInfo").hide();
        }
      } else {
        objProfileDetail.hide();
        $("#divInfoAlert").hide();
        objIFrame.show();
        objDivLoading.show();
        $("#send_token")
          .attr({
            action: baseUrl + "manage",
            target: "load_profile",
          })
          .submit();
        $("#btnManageProfile").html("Close");
        $("#divErrorInfo").hide();
      }
    } else {
      // $("#divInfoAlert").html("");
      // $("#divInfoAlert").append("<strong>Info!</strong> Please add a Payment Profile.");
      // $("#divInfoAlert").show();
      // objDivLoading.hide();
      // $("#divErrorInfo").hide();
      objProfileDetail.hide();
      $("#divInfoAlert").hide();
      objIFrame.show();
      objDivLoading.show();
      $("#send_token")
        .attr({
          action: baseUrl + "manage",
          target: "load_profile",
        })
        .submit();
      $("#btnManageProfile").html("Close");
      $("#divErrorInfo").hide();
    }
  } else {
    objDivLoading.hide();
    $("#divErrorInfo").html("");
    if (objErrorDesc.val().length > 250) {
      $("#divErrorInfo").append("<strong>Error!</strong> " + objErrorDesc.val().substr(0, 250));
    } else {
      $("#divErrorInfo").append("<strong>Error!</strong> " + objErrorDesc.val());
    }
    $("#divErrorInfo").show();
    $("#divInfoAlert").hide();
  }

  //   $(".chkPrimary").on("click", function () {
  //     $(this).toggleClass("fa-check-square").toggleClass("fa-square");
  //   });
  $("input.with-font").on("change", function () {
    $("input.with-font").not(this).prop("checked", false);
  });
  $("input.with-font").on("click", function () {
    //$("input.with-font").not(this).prop("checked", false);
    objDivLoading.show();
    //if (this.checked) {
    var objId = this.id.replace("chkPrimayId", "hiddenPaymentProfileID");
    var objvalue = document.getElementById(objId).value;
    PreferredPayId = objvalue;
    $("#preferredPayId").val(objvalue);
    $("#send_prefereed_pay_method")
      .attr("action", function (i, value) {
        return value + "&preferredId=" + PreferredPayId;
      })
      .submit();
    //}
  });

  $("#load_profile").on("load", function () {
    parent.$("#divLoading").hide();
  });

  // $(".toast").toast({ delay: 2000 });
  // $(".toast").toast("show");
});

function OpenManageProfile() {
  var objProfileDetail = $("#divProfileDetails");
  var objIFrame = $("#divIframe");
  var objDivLoading = $("#divLoading");

  if ($("#token").val().length > 0) {
    if ($.trim($("#btnManageProfile").html()) === "Close") {
      //objProfileDetail.show();
      objDivLoading.show();
      objIFrame.hide();
      $("#btnManageProfile").html("Manage Profile");
      history.go(0);
    } else {
      objProfileDetail.hide();
      $("#divInfoAlert").hide();
      objIFrame.show();
      objDivLoading.show();
      $("#send_token")
        .attr({
          action: baseUrl + "manage",
          target: "load_profile",
        })
        .submit();
      $("#btnManageProfile").html("Close");
    }
  } else {
    $("#divErrorInfo").html("");
    $("#divErrorInfo").append(
      "<strong>Error!</strong> An error occoured while retriving token. Please re load the page again or try after some time."
    );
    $("#divErrorInfo").show();
    $("#divInfoAlert").hide();
  }
}

function GenerateBlankRow() {
  var strRow = "";
  strRow += "<tr>";
  strRow += "<td colspan='4' style='height:50px;'></td>";
  strRow += "<tr>";
  return strRow;
}

function GenerateBankAccountRow(item, index) {
  var strRow = "";
  strRow += "<tr>";
  strRow += "<td>" + item.payment.bankAccount.accountNumber + "</td>";
  strRow += "<td>" + item.payment.bankAccount.routingNumber + "</td>";
  strRow +=
    "<td>" +
    item.payment.bankAccount.accountType.charAt(0).toUpperCase() +
    item.payment.bankAccount.accountType.substr(1).toLowerCase() +
    "</td>";
  if ($("#preferredPayId").val() == item.customerPaymentProfileId) {
    strRow +=
      "<td align='center'><input type='checkbox' id='chkPrimayId_" +
      index +
      "' name='chk' class='with-font' checked='checked'/>";
  } else {
    strRow +=
      "<td align='center'><input type='checkbox' id='chkPrimayId_" + index + "' name='chk' class='with-font' />";
  }
  strRow +=
    "<input type='hidden' id='hiddenPaymentProfileID_" +
    index +
    "' value='" +
    item.customerPaymentProfileId +
    "'></input></td>";
  strRow += "</tr>";
  return strRow;
}

function GenerateCreditCardRow(item, index) {
  var strRow = "";
  strRow += "<tr>";
  strRow += "<td>" + item.payment.creditCard.cardNumber + "</td>";
  strRow += "<td>" + item.payment.creditCard.expirationDate + "</td>";
  strRow += "<td>" + GetFormatedCardNumber(item.payment.creditCard.cardType) + "</td>";
  if ($("#preferredPayId").val() == item.customerPaymentProfileId) {
    strRow +=
      "<td align='center'><input type='checkbox' id='chkPrimayId_" +
      index +
      "' name='chk' class='with-font' checked='checked'/>";
  } else {
    strRow +=
      "<td align='center'><input type='checkbox' id='chkPrimayId_" + index + "' name='chk' class='with-font' />";
  }
  strRow +=
    "<input type='hidden' id='hiddenPaymentProfileID_" +
    index +
    "' value='" +
    item.customerPaymentProfileId +
    "'></input></td>";
  strRow += "</tr>";

  return strRow;
}

function GenerateBankAccountHeader() {
  var strRow = "";
  strRow += "<table id='tblBankAccount' cellpadding='10' cellspacing='20' border='0' width='100%'>";
  strRow += "<tr height='10px'>";
  strRow +=
    "<td width='25%'><b>Account Number</b></td><td width='25%'><b>Routing Number</b></td><td width='25%'><b>Account Type</b></td><td width='25%'><b>Preferred&nbspPayment&nbspMethod</b></td>";
  strRow += "</tr>";
  return strRow;
}

function GenerateCreditCardHeader() {
  var strRow = "";
  strRow += "<table id='tblCreditCard cellpadding='10' cellspacing='20' border='0' width='100%'>";
  strRow += "<tr height='10px'>";
  strRow +=
    "<td width='25%'><b>Card Number</b></td><td width='25%'><b>Expiration Date</b></td><td width='25%'><b>Card Type</b></td><td width='25%'><b>Preferred&nbspPayment&nbsp;Method</b></td>";
  strRow += "</tr>";
  return strRow;
}

function GenerateCreditCardTableEndTag() {
  var strRow = "";
  strRow += "</table>";
  return strRow;
}

function GenerateBankAccountTableEndTag() {
  var strRow = "";
  strRow += "</table>";
  return strRow;
}

function GetFormatedCardNumber(cardTypeToFormat) {
  var cardType = "";
  switch (cardTypeToFormat) {
    case "Visa":
      cardType = "Visa";
      break;
    case "AmericanExpress":
      cardType = "American Express";
      break;
    case "MasterCard":
      cardType = "Master Card";
      break;
    case "Discover":
      cardType = "Discover";
      break;
    case "JCB":
      cardType = "JCB";
      break;
    case "DinersClub":
      cardType = "Diners Club";
      break;
    default:
      cardType = "NA";
  }
  return cardType;
}
