// JavaScript Document



//Do not allow white space in a field
//Example: onkeyup="nospaces(this)"
function nospaces(thefield) {
thefield.value=thefield.value.replace(/\s/g,'');
} //End Function



function setmenukey(menukey) {

var theprotocol = location.protocol;
var thedomain = document.domain;
var xmlhttp;

if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  } else  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function() {
  if (xmlhttp.readyState==4 && xmlhttp.status==200) {
	}
  }
xmlhttp.open("GET","/index.html?MenuKey="+menukey);
xmlhttp.send();
} //End Function



function togglepassword() {
	var passwordField = document.getElementById("WebPassword");
	var togglealink = document.getElementById("showhidepass");
	var value = passwordField.value;
	if(passwordField.type == "password") {
		passwordField.type = "text";
		togglealink.innerHTML = "hide password";
	} else {
		passwordField.type = "password";
		togglealink.innerHTML = "show password";
	}
	passwordField.value = value;
		} //End Function
		
			
		
		
function checkusername(testuser,statusfld)
{
var usernametotest = testuser.value;
var statusfield = statusfld;
var theprotocol = location.protocol;
var thedomain = document.domain;

var xmlhttp;

if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    statusfield.innerHTML=xmlhttp.responseText;
	if (statusfield.innerHTML=="Available"){
	statusfield.className = "valid";
	} else {
	statusfield.className = "invalid";
	}
	}
  }
xmlhttp.open("GET",theprotocol+"//"+thedomain+"/4DCGI/index.html?action=common&activity=checkusername&referenceurl="+usernametotest);
xmlhttp.send();
} //End Function

// Serialize form data into a query string - Encode a set of form elements as a string for submission.

function serialize(form) {
    var field, l, s = [];
    if (typeof form == 'object' && form.nodeName == "FORM") {
        var len = form.elements.length;
        for (var i=0; i<len; i++) {
            field = form.elements[i];
            if (field.name && !field.disabled && field.type != 'file' && field.type != 'reset' && field.type != 'submit' && field.type != 'button') {
                if (field.type == 'select-multiple') {
                    l = form.elements[i].options.length; 
                    for (var j=0; j<l; j++) {
                        if(field.options[j].selected)
                            s[s.length] = encodeURIComponent(field.name) + "=" + encodeURIComponent(field.options[j].value);
                    }
                } else if ((field.type != 'checkbox' && field.type != 'radio') || field.checked) {
                    s[s.length] = encodeURIComponent(field.name) + "=" + encodeURIComponent(field.value);
                }
            }
        }
    }
    return s.join('&').replace(/%20/g, '+');
}


// Serialize form data into an array - Encode a set of form elements as an array of names and values.

function serializeArray(form) {
    var field, l, s = [];
    if (typeof form == 'object' && form.nodeName == "FORM") {
        var len = form.elements.length;
        for (var i=0; i<len; i++) {
            field = form.elements[i];
            if (field.name && !field.disabled && field.type != 'file' && field.type != 'reset' && field.type != 'submit' && field.type != 'button') {
                if (field.type == 'select-multiple') {
                    l = form.elements[i].options.length; 
                    for (j=0; j<l; j++) {
                        if(field.options[j].selected)
                            s[s.length] = { name: field.name, value: field.options[j].value };
                    }
                } else if ((field.type != 'checkbox' && field.type != 'radio') || field.checked) {
                    s[s.length] = { name: field.name, value: field.value };
                }
            }
        }
    }
    return s;
}


//Character Counter Object

function updatecounter(textobj,counterobj) {
var n = textobj.value.length;
document.getElementById(counterobj).innerHTML = n;
}




// Hide Show Function

function mbrmaxshowhide(idtoshow) {
if (document.getElementById(idtoshow).getAttribute("class")=="mbrmax-show") {
document.getElementById(idtoshow).setAttribute("class", "mbrmax-collapse");
} else {
document.getElementById(idtoshow).setAttribute("class", "mbrmax-show");
}
} // End function

function qtycheck(QtyObj,NumberLeft)
  {
	      if (QtyObj.value < 1)
    {
	  QtyObj.value = 1;
    }
    if (QtyObj.value > NumberLeft)
    {
		alert('Please note that there are only '+NumberLeft+' remaining.');
	  QtyObj.value = NumberLeft;
    }
  }

// product info sheet popup
function MoreInfo(page) {
    var infoSheetWin = null;
	var width = 400;
	var height = 500;

	infoSheetWin = window.open(page, "infoPopup", "width=" + width+ ",height=" + height + ",toolbar=no,scrollbars=yes,scrolling=yes");
	if (window.focus) infoSheetWin.focus();
	}

function mbrmaxFormValidate(theForm,checkCaptcha) {
		if (checkCaptcha === undefined) {
    checkCaptcha = false;
  } 
      if (theForm.checkValidity() == false) {
        event.preventDefault();
        event.stopPropagation();
        theForm.classList.add("mbrmax-was-validated");
        } else {
                if (checkCaptcha) {
     if (grecaptcha.getResponse(recaptcha1).length == 0){
		event.preventDefault();
        event.stopPropagation();
        alert("Please complete the Captcha.");
		}
  } //End if (checkCaptcha)
      } //if (theForm.checkValidity() == false)
} //End Function


function htmlCheck(theForm) {
var hashtml = false;
var i;
for (i = 0; i < theForm.length; i++) {
  if (theForm.elements[i].value.includes("</") || theForm.elements[i].value.includes("<br>")) {
  hashtml = true;
  i = theForm.length;
  } //END if
} //END for
if (hashtml) {
  event.preventDefault();
  event.stopPropagation();
  alert("HTML Not Permitted.");
}//END if
} //End Function



function clearFieldValue(theField) {
document.getElementById(theField).value="";
		}
		
function copyToClipboard(elementId,option) {
  var aux = document.createElement("input");
  switch(option) {
    case 1: //Used for copying all text for an element
      aux.setAttribute("value", document.getElementById(elementId).innerHTML); 
        break;
    case 2: // Used to copy the value of the specified element (typically a hidden input field)
      aux.setAttribute("value", document.getElementById(elementId).value);
        break;
    default: //0 is default - Used for copying selected text
        aux.setAttribute("value", window.getSelection().toString()); 
}
  document.body.appendChild(aux);
  aux.select();
  document.execCommand("copy");
  document.body.removeChild(aux);
  event.preventDefault();
}



function MM_jumpMenuGo(objId,targ,restore){ //v9.0
  var selObj = null;  with (document) { 
  if (getElementById) selObj = getElementById(objId);
  if (selObj) eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0; }
}

function Clickheretoprint()
{ 
  var disp_setting="toolbar=yes,location=no,directories=yes,menubar=yes,"; 
      disp_setting+="scrollbars=yes,width=650, height=600, left=100, top=25"; 
  var content_vlue = document.getElementById("print_content").innerHTML; 
  var title_value = document.getElementById("page_title").innerHTML; 
  
  var docprint=window.open("","",disp_setting); 
   docprint.document.open(); 
   docprint.document.write('<html><head><title>'+title_value+'</title>'); 
   docprint.document.write('</head><body onLoad="self.print()"><center>');          
   docprint.document.write(content_vlue);          
   docprint.document.write('</center></body></html>'); 
   docprint.document.close(); 
   docprint.focus(); 
}


function goBack(message){
  if (typeof message == 'undefined' || message == null || message == '') {
    window.history.back();
      event.preventDefault();
    } else {
  var x = confirm(message);
if(x == true) {
  window.history.back();
    event.preventDefault();
}
  }
  }
  
