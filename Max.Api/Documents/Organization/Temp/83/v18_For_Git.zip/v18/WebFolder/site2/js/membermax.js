// JavaScript Document


//Character Counter Object

function updatecounter(textobj,counterobj) {
var n = textobj.value.length;
document.getElementById(counterobj).innerHTML = n;
}




// Hide Show Function

function mbrmaxshowhide(idtoshow) {
if (document.getElementById(idtoshow).getAttribute("class")=="mbrmax-show") {
document.getElementById(idtoshow).setAttribute("class", "mbrmax-collapse");
} else {
document.getElementById(idtoshow).setAttribute("class", "mbrmax-show");
}
} // End function

function qtycheck(QtyObj,NumberLeft)
  {
	      if (QtyObj.value < 1)
    {
	  QtyObj.value = 1;
    }
    if (QtyObj.value > NumberLeft)
    {
		alert('Please note that there are only '+NumberLeft+' remaining.');
	  QtyObj.value = NumberLeft;
    }
  }

// product info sheet popup
function MoreInfo(page) {
    var infoSheetWin = null;
	var width = 400;
	var height = 500;

	infoSheetWin = window.open(page, "infoPopup", "width=" + width+ ",height=" + height + ",toolbar=no,scrollbars=yes,scrolling=yes");
	if (window.focus) infoSheetWin.focus();
	}

function mbrmaxFormValidate(theForm) {
      if (theForm.checkValidity() == false) {
        event.preventDefault();
        event.stopPropagation();
        theForm.classList.add("mbrmax-was-validated");
      }
}

function clearFieldValue(theField) {
document.getElementById(theField).value="";
		}
		
function copyToClipboard(elementId,option) {
  var aux = document.createElement("input");
  switch(option) {
    case 1: //Used for copying all text for an element
      aux.setAttribute("value", document.getElementById(elementId).innerHTML); 
        break;
    case 2: // Used to copy the value of the specified element (typically a hidden input field)
      aux.setAttribute("value", document.getElementById(elementId).value);
        break;
    default: //0 is default - Used for copying selected text
        aux.setAttribute("value", window.getSelection().toString()); 
}
  document.body.appendChild(aux);
  aux.select();
  document.execCommand("copy");
  document.body.removeChild(aux);
  event.preventDefault();
}



function MM_jumpMenuGo(objId,targ,restore){ //v9.0
  var selObj = null;  with (document) { 
  if (getElementById) selObj = getElementById(objId);
  if (selObj) eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0; }
}

function Clickheretoprint()
{ 
  var disp_setting="toolbar=yes,location=no,directories=yes,menubar=yes,"; 
      disp_setting+="scrollbars=yes,width=650, height=600, left=100, top=25"; 
  var content_vlue = document.getElementById("print_content").innerHTML; 
  var title_value = document.getElementById("page_title").innerHTML; 
  
  var docprint=window.open("","",disp_setting); 
   docprint.document.open(); 
   docprint.document.write('<html><head><title>'+title_value+'</title>'); 
   docprint.document.write('</head><body onLoad="self.print()"><center>');          
   docprint.document.write(content_vlue);          
   docprint.document.write('</center></body></html>'); 
   docprint.document.close(); 
   docprint.focus(); 
}


function goBack(message){
  if (typeof message == 'undefined' || message == null || message == '') {
    window.history.back();
      event.preventDefault();
    } else {
  var x = confirm(message);
if(x == true) {
  window.history.back();
    event.preventDefault();
}
  }
  }
  
