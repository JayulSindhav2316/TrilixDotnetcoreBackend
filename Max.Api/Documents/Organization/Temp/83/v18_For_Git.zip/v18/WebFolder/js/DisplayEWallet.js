var token = "";
var baseUrl = "";
var strHTML = "";
var strBankHTML = "";
var PreferredPayId = "";
var selectedPayMethod="";

$(function () {
  $('select[id="inputPay"]').change(function(){
    selectedPayMethod = $(this).children("option:selected").val();
    $("#payment_method").val(selectedPayMethod);
    });
    if($('select[id="inputPay"]').val()==1)
    {
      selectedPayMethod = $('select[id="inputPay"]').val();
      $("#payment_method").val(selectedPayMethod);
      //DisplayPaymentProfileDetails();
    }
});

function DisplayPaymentProfileDetails() {
  var objProfileDetail = $("#divProfileDetails");
  var objResponse;

  $("#divBankAccountDetail").hide();
  $("#divCCDetail").hide();

  objResponse = $("#response").val();
  if (objResponse.length > 0) {
    var objParseResponse = JSON.parse(objResponse);
    var objPaymentProfileArray = [];
    var isBankAccountHeader = true;
    var isCreditCardHeader = true;

    objPaymentProfileArray = objParseResponse.profile.paymentProfiles;
    if (objPaymentProfileArray != null) {
      if (objPaymentProfileArray.length > 0) {
        //strHTML += "<table id='tblSearchCorePrograms' class='list-table' width='100%' border='0'>";
        $(objPaymentProfileArray).each(function (index, item) {
          if (item.payment.bankAccount != null) {
            if (isBankAccountHeader) {
              strBankHTML += GenerateBankAccountHeader();
              isBankAccountHeader = false;
            }
            strBankHTML += GenerateBankAccountRow(item, index);
            //objTblbankAccount.html(strBankHTML);
          } else if (item.payment.creditCard != null) {
            if (isCreditCardHeader) {
              strHTML += GenerateCreditCardHeader();
              isCreditCardHeader = false;
            }
            strHTML += GenerateCreditCardRow(item, index);
            //objTblCCDetail.html(strHTML);
          }
        });
        if (strBankHTML.length > 0) {
          strBankHTML += GenerateBankAccountTableEndTag();
        }
        if (strHTML.length > 0) {
          strHTML += GenerateCreditCardTableEndTag();
        }
        objProfileDetail.show();
        //objProfileDetail.html(strHTML);
        if (strBankHTML.length > 0 && strHTML.length > 0) {
          $("#divBlank").show();
        }
        if (strBankHTML.length > 0) {
          $("#divBankAccountDetail").html("");
          $("#divBankAccountDetail").html(strBankHTML);
          $("#divBankAccountDetail").show();
          $("#paymentprofilepage").show();
        }
        if (strHTML.length > 0) {
          $("#divCCDetail").html("");
          $("#divCCDetail").html(strHTML);
          $("#divCCDetail").show();
          $("#paymentprofilepage").show();
        }
      }
    }
  }
  $('input[name="chk"]').on("change", function () {
    $('input[name="chk"]').not(this).prop("checked", false);
  });
  $("input.with-font").on("click", function () {
    selectpaymentprofile(this.id);
  });
}
//$("input.with-font").on("click", function () {
//$("input.with-font").not(this).prop("checked", false);
//var objId = this.id.replace("chkPrimayId", "hiddenPaymentProfileID");
//var objvalue = document.getElementById(objId).value;
// PreferredPayId = objvalue;
// $("#preferredPayId").val(objvalue);
//});

function GenerateBankAccountRow(item, index) {
  var strRow = "";
  strRow += "<tr>";
  strRow += "<td><input type='checkbox' id='chkPrimayId_" + index + "' name='chk' class='with-font' />";
  strRow += "<td>" + item.payment.bankAccount.accountNumber + "</td>";
  strRow += "<td>" + item.payment.bankAccount.routingNumber + "</td>";
  strRow +=
    "<td>" + GetFormatedAccountType(item.payment.bankAccount.accountType);
    // item.payment.bankAccount.accountType.charAt(0).toUpperCase() +
    // item.payment.bankAccount.accountType.substr(1).toLowerCase() +
    +"</td>";
  strRow +=
    "<input type='hidden' id='hiddenPaymentProfileID_" +
    index +
    "' value='" +
    item.customerPaymentProfileId +
    "'></input></td>";
  strRow += "</tr>";
  return strRow;
}

function GenerateCreditCardRow(item, index) {
  var strRow = "";
  strRow += "<tr>";
  strRow += "<td><input type='checkbox' id='chkPrimayId_" + index + "' name='chk' class='with-font' />";
  strRow += "<td>" + item.payment.creditCard.cardNumber + "</td>";
  strRow += "<td>" + item.payment.creditCard.expirationDate + "</td>";
  strRow += "<td>" + GetFormatedCardNumber(item.payment.creditCard.cardType) + "</td>";
  strRow +=
    "<input type='hidden' id='hiddenPaymentProfileID_" +
    index +
    "' value='" +
    item.customerPaymentProfileId +
    "'></input></td>";
  strRow += "</tr>";

  return strRow;
}

function GenerateBankAccountHeader() {
  var strRow = "";
  strRow += "<table id='tblBankAccount' cellpadding='10' cellspacing='20' border='0' width='100%'>";
  strRow += "<tr height='10px'>";
  strRow +=
    "<td width='25%'></td><td width='25%'><b>Account Number</b></td><td width='25%'><b>Routing Number</b></td><td width='25%'><b>Account Type</b></td>";
  strRow += "</tr>";
  return strRow;
}

function GenerateCreditCardHeader() {
  var strRow = "";
  strRow += "<table id='tblCreditCard cellpadding='10' cellspacing='20' border='0' width='100%'>";
  strRow += "<tr height='10px'>";
  strRow +=
    "<td width='25%'></td><td width='25%'><b>Card Number</b></td><td width='25%'><b>Expiration Date</b></td><td width='25%'><b>Card Type</b></td>";
  strRow += "</tr>";
  return strRow;
}

function GenerateCreditCardTableEndTag() {
  var strRow = "";
  strRow += "</table>";
  return strRow;
}

function GenerateBankAccountTableEndTag() {
  var strRow = "";
  strRow += "</table>";
  return strRow;
}

function GetFormatedCardNumber(cardTypeToFormat) {
  var cardType = "";
  switch (cardTypeToFormat) {
    case "Visa":
      cardType = "Visa";
      break;
    case "AmericanExpress":
      cardType = "American Express";
      break;
    case "MasterCard":
      cardType = "Master Card";
      break;
    case "Discover":
      cardType = "Discover";
      break;
    case "JCB":
      cardType = "JCB";
      break;
    case "DinersClub":
      cardType = "Diners Club";
      break;
    default:
      cardType = "NA";
  }
  return cardType;
}
function ValidatePaymentProfileSelection()
{
  if(selectedPayMethod == 5)
    {
      if($("#preferredPayId").val().length==0)
      {
        alert('Please select Payment Profile from the grid.');
        return false;
      }
    }
  return true;
}
function GetFormatedAccountType(accountTypeToFormat){
  var accountType="";
  switch (accountTypeToFormat) {
      case "businessChecking":
        accountType="Business Checking";
        break;
      case "checking":
        accountType="Personal Checking";
        break;
      case "savings":
        accountType="Personal Savings";
        break;
      default:
        accountType = "NA";
  }
  return accountType;
}
