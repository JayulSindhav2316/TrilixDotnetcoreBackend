var token = "";
var baseUrl = "";
var strHTML = "";
var strBankHTML = "";
var PreferredPayId = "";

$(function () {
  var objProfileDetail = $("#divProfileDetails");
  var objIFrame = $("#divIframe");
  var objDivLoading = $("#divLoading");
  var objErrorDesc = $("#errorMsg");
  var objBillingAddressPayProfileId = $("#billingAddressPayProfileId").val();

  var objResponse;

  $("#divFieldSetBankAccount").hide();
  $("#divFieldSetCreditCard").hide();

  objDivLoading.show();
  objProfileDetail.hide();
  objIFrame.hide();
  $("#divFooter").hide();

  baseUrl = $("#baseUrl").val();
  objResponse = $("#response").val();
  if (objErrorDesc.val().length == 0) {
    if (objResponse.length > 0) {
      var objParseResponse = JSON.parse(objResponse);
      var objPaymentProfileArray = [];
      var isBankAccountHeader = true;
      var isCreditCardHeader = true;
      var isInsertBlankRow = false;
      var showCountry=false;

      objPaymentProfileArray = objParseResponse.profile.paymentProfiles;
      if (objPaymentProfileArray != null) {
        if (objPaymentProfileArray.length > 0) {
          ResetFormValues();
          $(objPaymentProfileArray).each(function (index, item) {
            if(item.customerPaymentProfileId == objBillingAddressPayProfileId)
              SetBillingAddress(item);
            
              if (item.payment.bankAccount != null) {
              showCountry=false;
              if (isBankAccountHeader) {
                strBankHTML += GenerateBankAccountHeader();
                isBankAccountHeader = false;
              }
              strBankHTML += GenerateBankAccountRow(item, index);
              strBankHTML += GenerateDetailRow(item,index,showCountry);
            } else if (item.payment.creditCard != null) {
              showCountry=true;
              if (isCreditCardHeader) {
                strHTML += GenerateCreditCardHeader();
                isCreditCardHeader = false;
              }
              strHTML += GenerateCreditCardRow(item, index);
              strHTML += GenerateDetailRow(item,index,showCountry);
            }
          });
          if (strBankHTML.length > 0) {
            strBankHTML += GenerateBankAccountTableEndTag();
          }
          if (strHTML.length > 0) {
            strHTML += GenerateCreditCardTableEndTag();
          }
          objProfileDetail.show();
          if (strBankHTML.length > 0 && strHTML.length > 0) {
            $("#divBlank").show();
          }
          if (strBankHTML.length > 0) {
            $("#divBankAccountDetail").html(strBankHTML);
            $("#divFieldSetBankAccount").show();
          }
          if (strHTML.length > 0) {
            $("#divCCDetail").html(strHTML);
            $("#divFieldSetCreditCard").show();
          }
          objIFrame.hide();
          objDivLoading.hide();
          $("#divFooter").hide();
          $("#divInfoAlert").hide();
          $("#divErrorInfo").hide();
        } else {
          $("#divInfoAlert").show();
          objDivLoading.hide();
          $("#divErrorInfo").hide();
        }
      } else {
        objProfileDetail.hide();
        $("#divInfoAlert").hide();
        objIFrame.show();
        objDivLoading.hide();
        $("#btnManageProfile").html("Close");
        $("#divErrorInfo").hide();
        $("#divFooter").show();
      }
    } else {
      objProfileDetail.hide();
      $("#divInfoAlert").hide();
      objIFrame.show();
      objDivLoading.hide();
      $("#btnManageProfile").html("Close");
      $("#divErrorInfo").hide();
      $("#divFooter").show();
    }
  } else {
    objDivLoading.hide();
    $("#divErrorInfo").html("");
    if (objErrorDesc.val().length > 250) {
      $("#divErrorInfo").append("<strong>Error!</strong> " + objErrorDesc.val().substr(0, 250));
    } else {
      $("#divErrorInfo").append("<strong>Error!</strong> " + objErrorDesc.val());
    }
    $("#divErrorInfo").show();
    $("#divInfoAlert").hide();
    objProfileDetail.hide();
    objIFrame.hide();
    $("#divFooter").hide();
    $("#btnManageProfile").prop('disabled', true);
  }

  //   $(".chkPrimary").on("click", function () {
  //     $(this).toggleClass("fa-check-square").toggleClass("fa-square");
  //   });
  $("input.with-font").on("change", function () {
    $("input.with-font").not(this).prop("checked", false);
  });
  $("input.with-font").on("click", function () {
    var prefPayChecked = $('input.with-font:checked').length;
    $(this).prop('checked', true);
    if (prefPayChecked === 0) {
        alert('Please select at least one Preferred Payment Method.');
    }
    else{
        objDivLoading.show();
        var objId = this.id.replace("chkPrimayId", "hiddenPaymentProfileID");
        var objvalue = document.getElementById(objId).value;
        PreferredPayId = objvalue;
        $("#preferredPayId").val(objvalue);
          
        $("#send_prefereed_pay_method")
        .attr("action", function (i, value) {
          return value + "?Action=AuthNet_UpdatePrefPayId&preferredId=" + PreferredPayId;
        })
        .submit();
      }
  });

  $("#load_profile").on("load", function () {
    parent.$("#divLoading").hide();
  });
  
  // $(".toast").toast({ delay: 2000 });
  // $(".toast").toast("show");
});

function OpenManageProfile() {
  var objProfileDetail = $("#divProfileDetails");
  var objIFrame = $("#divIframe");
  var objDivLoading = $("#divLoading");
  var objErrorDesc = $("#errorMsg");

  if ($.trim($("#btnManageProfile").html()) === "Close") {
    //objProfileDetail.show();
    objDivLoading.show();
    objIFrame.hide();
    $("#divFooter").hide();
    $("#btnManageProfile").html("Manage Profile");
      $("#send_prefereed_pay_method")
      .attr("action", function (i, value) {
        return value
      })
      .submit();     
    
  } else {
    if(objErrorDesc.val().length==0){
      objIFrame.show();
      $("#divFooter").show();
      $("#rdCCPayMethodType").attr('disabled',false);
      $("#rdBankPayMethodType").attr('disabled',false);
    }else{
      objIFrame.hide();
      $("#divFooter").hide();
    }
    objProfileDetail.hide();
    $("#divInfoAlert").hide();
    objDivLoading.hide();
    $("#btnManageProfile").html("Close");
  }
}

function GenerateBlankRow() {
  var strRow = "";
  strRow += "<tr>";
  strRow += "<td colspan='4' style='height:50px;'></td>";
  strRow += "<tr>";
  return strRow;
}
function SetBillingAddress(item){
  $("#cc-name").val($.trim(item.billTo.firstName.replace(/&nbsp;|,/g," ")));
  $("#cc-lastname").val($.trim(item.billTo.lastName.replace(/&nbsp;|,/g," ")));
  $("#cc-street").val($.trim(item.billTo.address.replace(/&nbsp;|,/g," ")));
  $("#cc-city").val($.trim(item.billTo.city.replace(/&nbsp;|,/g," ")));
  $("#cc-state").val($.trim(item.billTo.state));
  $("#cc-zip").val($.trim(item.billTo.zip));
  //$("#cc-country").val("USA");
  if (item.payment.creditCard != null)
    $("#cc-country").val($.trim(item.billTo.country.replace(/&nbsp;|,/g," ")))
  else
    $("#cc-country").val("-1");

  $("#hidden-cc-name").val($.trim(item.billTo.firstName.replace(/&nbsp;|,/g," ")));
  $("#hidden-cc-lastname").val($.trim(item.billTo.lastName.replace(/&nbsp;|,/g," ")));
  $("#hidden-cc-street").val($.trim(item.billTo.address.replace(/&nbsp;|,/g," ")));
  $("#hidden-cc-city").val($.trim(item.billTo.city.replace(/&nbsp;|,/g," ")));
  $("#hidden-cc-state").val($.trim(item.billTo.state));
  $("#hidden-cc-zip").val($.trim(item.billTo.zip));
  //$("#cc-country").val("USA");
  
  if (item.payment.creditCard != null)
    $("#hidden-cc-country").val($.trim(item.billTo.country.replace(/&nbsp;|,/g," ")))
  else
    $("#hidden-cc-country").val("USA");
}

function GenerateDetailRow(item,index,showCountry){
  var strRow = "";
  strRow += "<tr>";
  strRow += "<td colspan='5'>";
  strRow += "<div id='divDetailRow_"+index+"' style='display:none;'>";
  strRow +="<table border='0' width='90%' style='border-style: solid;border-width: thin;' cellspacing='10' cellpadding='10'>";
  strRow +="<tr>";
  strRow +="<td width='5%'></td><td class='mbrmax-float-left' colspan='2'>";
  strRow +="<span><b>Billing Address:</b></span>";
  strRow +="</td>";
  strRow +="</tr>";
  strRow +="<tr>";
  strRow +="<td width='5%'></td><td class='mbrmax-float-left' colspan='2'>";
  strRow +="<span>"+$.trim(item.billTo.firstName)+"</span>&nbsp;<span>"+$.trim(item.billTo.lastName)+"</span>";
  strRow +="</td>";
  strRow +="</tr>";
  strRow +="<tr>";
  strRow +="<td width='5%'></td><td class='mbrmax-float-left' colspan='2'>";
  strRow +="<span>"+$.trim(item.billTo.address.replace(/&nbsp;|,/g," "))+"</span>";
  strRow +="</td>";
  strRow +="</tr>";
  strRow +="<tr>";
  strRow +="<td width='5%'></td><td class='mbrmax-float-left' colspan='2'>";
  strRow +="<span>"+$.trim(item.billTo.city)+"</span>,&nbsp;<span>"+$.trim(item.billTo.state)+"</span>,&nbsp;<span>"+$.trim(item.billTo.zip)+"</span>";
  strRow +="</td>";
  strRow +="</tr>";
  if(showCountry){
    strRow +="<tr>";
    strRow +="<td width='5%'></td><td class='mbrmax-float-left' colspan='2'>";
    strRow +="<span>"+$.trim(item.billTo.country)+"</span>";
    strRow +="</td>";
    strRow +="</tr>";
  }
  strRow +="<tr>";
  strRow +="<td width='5%'></td><td class='mbrmax-float-right' colspan='2'>";
  strRow +="<input id='btnEdit_"+index+"' value='Edit' class='mbrmax-btn mbrmax-btn-primary' type='button' onclick='EditDetailRow("+item.customerPaymentProfileId+");'/>&nbsp;";
  strRow +="<input value='Delete' type='button' class='mbrmax-btn mbrmax-btn-danger' id='btnDelete_"+index+"' onclick='DeleteDetailRow("+item.customerPaymentProfileId+");'/>&nbsp;";
  strRow +="</td>";
  strRow +="</tr>";
  strRow +="<tr>";
  strRow +="<td width='5%'></td><td class='mbrmax-float-left' style='height:5px;' colspan='2'></td>";
  strRow +="</tr>";
  strRow +="</table>";
  strRow += "</div>";
  strRow += "</td>";
  strRow += "</tr>";

  return strRow;
}

function DeleteDetailRow(payProfileId){
  $("#paymentProfileId").val(payProfileId);
  if ($("#preferredPayId").val() == payProfileId) {
    alert('Preferred Payment Method can not be deleted!!');        
  }
  else{
  var result = confirm("Are you sure you want to delete this payment method?");
  if (result) {
      $("#form_payment_detail").attr("action", function (i, value) {
        return value + "?Action=CustomerPaymentProfile&role=Delete";
      })
      .submit();
    }
  }   
}

function EditDetailRow(payProfileId){
  $("#paymentProfileId").val(payProfileId);
  var objResponse = $("#response").val();
  if (objResponse.length > 0){
    var objParseResponse = JSON.parse(objResponse);
    var objPaymentProfileArray = [];
    objPaymentProfileArray = objParseResponse.profile.paymentProfiles;
    if (objPaymentProfileArray.length > 0) {
      $(objPaymentProfileArray).each(function (index,item){
        if(item.customerPaymentProfileId == payProfileId){
          SetBillingAddress(item);
          SetPaymentMethod(item);
        }
      });
    }
  }
}
function SetPaymentMethod(item){
  if (item.payment.bankAccount != null){
    $("#rdBankPayMethodType").attr('checked',true);
    $("#rdCCPayMethodType").attr('disabled',true);
    $("#bank-nameonaccount").val($.trim(item.payment.bankAccount.nameOnAccount.replace(/&nbsp;|,/g," ")));
    $("#bank-name").val($.trim(item.payment.bankAccount.bankName.replace(/&nbsp;|,/g," ")));
    $("#bank-number").val($.trim(item.payment.bankAccount.accountNumber));
    $("#bank-routing").val($.trim(item.payment.bankAccount.routingNumber));
    $("#bank-accountType").val($.trim(item.payment.bankAccount.accountType));
    //Hidden Variable
    $("#hidden-bank-nameonaccount").val($.trim(item.payment.bankAccount.nameOnAccount.replace(/&nbsp;|,/g," ")));
    $("#hidden-bank-name").val($.trim(item.payment.bankAccount.bankName.replace(/&nbsp;|,/g," ")));
    $("#hidden-bank-number").val($.trim(item.payment.bankAccount.accountNumber));
    $("#hidden-bank-routing").val($.trim(item.payment.bankAccount.routingNumber));
    $("#hidden-bank-accountType").val($.trim(item.payment.bankAccount.accountType));

    $("#divCardRow").hide();
    $("#divBankRow").removeClass('mbrmax-d-none');
    $("#divBankRow").show();
    $("#divCountry").addClass('mbrmax-d-none');
  }
  else if (item.payment.creditCard != null){
    var expDate=[];
    expDate = item.payment.creditCard.expirationDate.split('-');
    var year = expDate[0];
    year = year.substr(2,year.length);
    year= expDate[1] +' / '+year;
    $("#rdCCPayMethodType").attr('checked',true);
    $("#rdBankPayMethodType").attr('disabled',true);
    $("#cc-number").val($.trim(item.payment.creditCard.cardNumber));
    $("#cc-exp").val($.trim(year));
    $("#cc-cvc").val('');
    //Hidden Variable
    $("#hidden-cc-number").val($.trim(item.payment.creditCard.cardNumber));
    $("#hidden-cc-exp").val($.trim(item.payment.creditCard.expirationDate));
    $("#hidden-cc-cardType").val($.trim(item.payment.creditCard.cardType));
    
    $("#divCardRow").show();
    $("#divBankRow").hide();
    $("#divCountry").removeClass('mbrmax-d-none');
  }
  $("#divIframe").show();
  $("#divProfileDetails").hide();
  $("#divFooter").show();
  $("#btnManageProfile").html("Close");
}
function GenerateBankAccountRow(item, index) {
  var strRow = "";
  strRow += "<tr>";
  strRow += "<td>" + item.payment.bankAccount.accountNumber + "</td>";
  strRow += "<td>" + item.payment.bankAccount.routingNumber + "</td>";
  strRow +="<td class='mbrmax-text-nowrap'>" +GetFormatedAccountType(item.payment.bankAccount.accountType);+"</td>";
  if ($("#preferredPayId").val() == item.customerPaymentProfileId) {
    strRow +="<td class='mbrmax-text-center'><input type='checkbox' id='chkPrimayId_" + index +"' name='chk' class='with-font' checked='checked'/>";
  } 
  else {
    strRow +="<td class='mbrmax-text-center'><input type='checkbox' id='chkPrimayId_" + index + "' name='chk' class='with-font' />";
  }
  strRow +="<input type='hidden' id='hiddenPaymentProfileID_" + index +"' value='" + item.customerPaymentProfileId +"'></input></td>";
  strRow +="<td><div class='mbrmax-text-right'><img class='mbrmax-img-cursor' id='imgPlus_"+index+"' name='imgPlus_"+index+"' src='/images/down-transparent.png'></img></div></td>";  
  strRow += "</tr>";
  
  return strRow;
}

function GenerateCreditCardRow(item, index) {
  var strRow = "";
  strRow += "<tr>";
  strRow += "<td>" + item.payment.creditCard.cardNumber + "</td>";
  strRow += "<td>" + item.payment.creditCard.expirationDate + "</td>";
  strRow += "<td class='mbrmax-text-nowrap'>" + GetFormatedCardNumber(item.payment.creditCard.cardType) + "</td>";
  if ($("#preferredPayId").val() == item.customerPaymentProfileId) {
    strRow +="<td class='mbrmax-text-center'><input type='checkbox' id='chkPrimayId_" + index +"' name='chk' class='with-font' checked='checked'/>";
  } 
  else {
    strRow +="<td class='mbrmax-text-center'><input type='checkbox' id='chkPrimayId_" + index + "' name='chk' class='with-font' />";
  }
  strRow +="<input type='hidden' id='hiddenPaymentProfileID_" + index +"' value='" + item.customerPaymentProfileId +"'></input></td>";
  strRow +="<td><div class='mbrmax-text-right'><img class='mbrmax-img-cursor' id='imgPlus_"+index+"' name='imgPlus_"+index+"' src='/images/down-transparent.png'></img></div></td>";  
  strRow += "</tr>";

  return strRow;
}

function GenerateBankAccountHeader() {
  var strRow = "";
  strRow += "<table id='tblBankAccount' cellpadding='10' cellspacing='20' border='0' width='100%'>";
  strRow += "<tr height='10px'>";
  strRow += "<td width='25%'><b>Account Number</b></td><td width='25%'><b>Routing Number</b></td><td width='25%'><b>Account Type</b></td><td width='25%' class='mbrmax-text-nowrap'><b>Preferred Payment Method</b></td><td></td>";
  strRow += "</tr>";
  return strRow;
}

function GenerateCreditCardHeader() {
  var strRow = "";
  strRow += "<table id='tblCreditCard' cellpadding='10' cellspacing='20' border='0' width='100%'>";
  strRow += "<tr height='10px'>";
  strRow += "<td width='25%'><b>Card Number</b></td><td width='25%'><b>Expiration Date</b></td><td width='25%'><b>Card Type</b></td><td width='25%' class='mbrmax-text-nowrap'><b>Preferred Payment Method</b></td><td></td>";
  strRow += "</tr>";
  return strRow;
}

function GenerateCreditCardTableEndTag() {
  var strRow = "";
  strRow += "</table>";
  return strRow;
}

function GenerateBankAccountTableEndTag() {
  var strRow = "";
  strRow += "</table>";
  return strRow;
}

function GetFormatedCardNumber(cardTypeToFormat) {
  var cardType = "";
  switch (cardTypeToFormat) {
    case "Visa":
      cardType = "Visa";
      break;
    case "AmericanExpress":
      cardType = "American Express";
      break;
    case "MasterCard":
      cardType = "Master Card";
      break;
    case "Discover":
      cardType = "Discover";
      break;
    case "JCB":
      cardType = "JCB";
      break;
    case "DinersClub":
      cardType = "Diners Club";
      break;
    default:
      cardType = "NA";
  }
  return cardType;
}
function GetFormatedAccountType(accountTypeToFormat){
  var accountType="";
  switch (accountTypeToFormat) {
      case "businessChecking":
        accountType="Business Checking";
        break;
      case "checking":
        accountType="Personal Checking";
        break;
      case "savings":
        accountType="Personal Savings";
        break;
      default:
        accountType = "NA";
  }
  return accountType;
}

$(function($) {
  $('[data-numeric]').payment('restrictNumeric');
  $('.cc-number').payment('formatCardNumber');
  $('.cc-exp').payment('formatCardExpiry');
  $('.cc-cvc').payment('formatCardCVC');
  $.fn.toggleInputError = function(erred) {
  this.parent('.mbrmax-form-group').toggleClass('has-error', erred);
  return this;
};
$("input[name='rdPayMethodType']").click(function() {
  if($(this).val()==="Credit Card"){
    $("#divBankRow").hide();
    $("#divCardRow").show();
    $("#divCountry").removeClass('mbrmax-d-none');
  }
  else{
    $("#divBankRow").removeClass('mbrmax-d-none')
    $("#divBankRow").show();
    $("#divCardRow").hide();
    $("#divCountry").addClass('mbrmax-d-none');
  }
});
$("#btnSave").click(function (e){
  e.preventDefault();
  if(Validate())
  {
    var arrExpDate = $('.cc-exp').val().split('/');
    var expDate = '20'+$.trim(arrExpDate[1])+'-'+$.trim(arrExpDate[0]);
    var ccNumber = $('.cc-number').val();
    ccNumber = $.trim(ccNumber.replace(/\s/g, ''));
    var ccZip = $('.cc-zip').val();
    ccZip = $.trim(ccZip.replace(/\s/g, ''));
    $("#paymentCCNumber").val(ccNumber);
    $("#paymentExpDate").val($.trim(expDate));
    if($("#paymentProfileId").val().length>0){
      $("#form_payment_detail")
          .attr("action", function (i, value) {
            return value + "?Action=CustomerPaymentProfile&role=Edit";
          })
          .submit();
    }
    else{
      $("#form_payment_detail")
          .attr("action", function (i, value) {
            return value + "?Action=CustomerPaymentProfile&role=Add";
          })
          .submit();
      }
  }
  
});
$("#btnCancel").click(function(e){
  $("#btnManageProfile").html("Manage Profile");
  $("#send_prefereed_pay_method")
        .attr("action", function (i, value) {
          return value
        })
        .submit();
});
$("img").click(function(){
  var src = ($(this).attr('class') === 'mbrmax-img-cursor')
      ? 'mbrmax-img-cursor-transform'
      : 'mbrmax-img-cursor';
 var isDivToClose=false;

  if($("#openDetailDivId").val().length == 0){
    $("#openDetailDivId").val($(this).attr('id'));
  }
  else {
    if($("#openDetailDivId").val() != $(this).attr('id')){
      isDivToClose=true;
    }
  }
  $(this).removeClass("mbrmax-img-cursor mbrmax-img-cursor-transform");   
  $(this).addClass(src);
  var arrayIndex = $(this).attr('id').split('_');
  var divToShow = "divDetailRow_"+arrayIndex[1];
  var divToCloseId = $("#openDetailDivId").val();
  var arrayIndex = divToCloseId.split('_');
  var divToClose = "divDetailRow_"+arrayIndex[1];

  if(src==='mbrmax-img-cursor')
    document.getElementById(divToShow).style.display='none';
  else
    document.getElementById(divToShow).style.display='';
  
    if(isDivToClose){
      document.getElementById(divToClose).style.display='none';
      $('#'+divToCloseId).removeClass("mbrmax-img-cursor mbrmax-img-cursor-transform");
      $('#'+divToCloseId).addClass("mbrmax-img-cursor");
      $("#openDetailDivId").val($(this).attr('id'));
    }
    isDivToClose=false;
});
function Validate()
{
  var payMethod = $("input[name='rdPayMethodType']:checked").val()
  if(payMethod == "Credit Card"){
    var cardType = $.payment.cardType($('.cc-number').val());
    if(!($.trim($('.cc-number').val()).indexOf('XXXX')>-1)){
      $('.cc-number').toggleInputError(!$.payment.validateCardNumber($.trim($('.cc-number').val())));
    }
    $('.cc-exp').toggleInputError(!$.payment.validateCardExpiry($('.cc-exp').payment('cardExpiryVal')));
    $('.cc-cvc').toggleInputError(!$.payment.validateCardCVC($.trim($('.cc-cvc').val()), cardType));
    $('.cc-brand').text(cardType);
    $('.cc-street').toggleInputError(!isValidCharacters($.trim($('.cc-street').val())));
    $('.cc-zip').toggleInputError(!ValidateZip($.trim($('.cc-zip').val())));
    $('.cc-name').toggleInputError(!isValidCharacters($.trim($('.cc-name').val())));
    $('.cc-lastname').toggleInputError(!isValidCharacters($.trim($('.cc-lastname').val())));
    $('.cc-city').toggleInputError(!isValidCharacters($.trim($('.cc-city').val())));
    $('.cc-state').toggleInputError(!ValidateState($('.cc-state').val()));
    $('.cc-country').toggleInputError(!ValidateCountry($('.cc-country').val()));
    $('.validation').removeClass('text-danger text-success');
    $('.validation').addClass($('.has-error').length ? 'text-danger' : 'text-success');
  }
  else if(payMethod == "Bank Account"){
    $('.bank-nameonaccount').toggleInputError(!isValidCharacters($.trim($('.bank-nameonaccount').val())));
    $('.bank-name').toggleInputError(!isValidCharacters($.trim($('.bank-name').val())));
    if(!($.trim($('.bank-number').val()).indexOf('XXXX')>-1)){
      $('.bank-number').toggleInputError(!ValidateAccountNumber($.trim($('.bank-number').val())));
    }
    if(!($.trim($('.bank-routing').val()).indexOf('XXXX')>-1)){
      $('.bank-routing').toggleInputError(!ValidateRouting($.trim($('.bank-routing').val())));
    }
    $('.bank-accountType').toggleInputError(!ValidateAccountType($('.bank-accountType').val()));
    $('.cc-street').toggleInputError(!isValidCharacters($.trim($('.cc-street').val())));
    $('.cc-zip').toggleInputError(!ValidateZip($.trim($('.cc-zip').val())));
    $('.cc-name').toggleInputError(!isValidCharacters($.trim($('.cc-name').val())));
    $('.cc-lastname').toggleInputError(!isValidCharacters($.trim($('.cc-lastname').val())));
    $('.cc-city').toggleInputError(!isValidCharacters($.trim($('.cc-city').val())));
    $('.cc-state').toggleInputError(!ValidateState($('.cc-state').val()));
    //$('.cc-country').toggleInputError(!ValidateCountry($('.cc-country').val()));
    $('.validation').removeClass('text-danger text-success');
    $('.validation').addClass($('.has-error').length ? 'text-danger' : 'text-success');
  }
  var returnvalue = $('.has-error').length ? 'false' : 'true';
    if(returnvalue == "false")
      return false;
    else
      return true;
}
function ValidateCardName(strCardName){
  strCardName = $.trim(strCardName);
  if(strCardName.length==0)
    return false;
else if(strCardName.length>0)  
{
    for (i = 0; i < strCardName.length; i++) {
    var s = strCardName.charAt(i);
    if(!isLetter(s))
        return false;
    }
return true;
}
}
function ValidateStreet(strStreet)
{
  if(strStreet.length == 0)
    return false;
  else if(strStreet.length>0)
  {
    var streetNoCheck = isAlphaNumeric(strStreet);
    if(!streetNoCheck)
      return false;
  }
  return true;
}
function ValidateZip(strZip)
{
  if(strZip.length == 0)
    return false;
  else if(strZip.length<5)
    return false;
  else if(strZip.length>0)
  {
    var strZipCheck = isNumeric(strZip);
    if(!strZipCheck)
      return false;
  }
  return true;
}
function validateAccountName(strAccName)
{
  if(strAccName.length==0)
    return false;
  else if(strAccName.length>0)  
  {
    for (i = 0; i < strAccName.length; i++) {
      var s = strAccName.charAt(i);
      if(!isLetter(s))
        return false;
    }
  return true;
  }
}
function ValidateAccountNumber(strAccNumber)
{
  if(strAccNumber.length == 0)
    return false;
  else if(strAccNumber.length<6)
    return false;
  else if(strAccNumber.length>5)
  {
    var strAccNumberCheck = isNumeric(strAccNumber);
    if(!strAccNumberCheck)
      return false;
  }
  return true;
}
function ValidateRouting(strRouting)
{
  var t, n, i;
  t = "";
  for (i = 0; i < strRouting.length; i++) {
    c = parseInt(strRouting.charAt(i), 10);
    if (c >= 0 && c <= 9)
      t = t + c;
  }
  
  if(t.length !=9)
    return false;

  n = 0;
  for (i = 0; i < t.length; i += 3) {
    n += parseInt(t.charAt(i),     10) * 3
      +  parseInt(t.charAt(i + 1), 10) * 7
      +  parseInt(t.charAt(i + 2), 10);
  }
   
  if (n != 0 && n % 10 == 0)
    return true;
  else
    return false;
}
function ValidateAccountType(strAccType)
{
  if(strAccType =="-1")
    return false;
  else
    return true;
}
function ValidateState(strAccType)
{
  if(strAccType =="-1")
    return false;
  else
    return true;
}
function ValidateCountry(strAccType)
{
  if(strAccType =="-1")
    return false;
  else
    return true;
}

});
function isNumeric(c) {
  for (i = 0; i < c.length; i++) {
      var s = c.charAt(i);
      if (!((s >= "0") && (s <= "9"))) {
          return false;
      }
  }
  return true;
}
function isAlphaNumeric(c){
  for (i = 0; i < c.length; i++) {
      var s = c.charAt(i);
      if (!((s >= "0") && (s <= "9") || (s == " "))) {
          if(!isLetter(s))
            return false;
      }
  }
  return true;
}
function isLetter(c) {
  return (
    ((c >= "a") && (c <= "z")) || ((c >= "A") && (c <= "Z")) || (c == " ")     
  )
}

function isValidCharacters(str) {
  if(str.length==0)
    return false;
  else if(str.length>0)  
  {
    const char = ['<', '>', '%', '@', '&'];
    length = char.length;
    while(length--) {
      if (str.indexOf(char[length])!=-1) {
        return false
      }      
    }
    return true
  }  
}

function ResetFormValues()
{
  var payMethod = $("input[name='rdPayMethodType']:checked").val()
  $('.cc-name').val('');
  $('.cc-lastname').val('');
  $('.cc-street').val('');
  $('.cc-city').val('');
  $('.cc-zip').val('');
  $('.cc-state').val('-1');
  if (payMethod == "Credit Card"){
    $('.cc-number').val('');
    $('.cc-exp').val('');
    $('.cc-cvc').val('');
  }
  else {
    $('.bank-number').val('');
    $('.bank-nameonaccount').val('');
    $('.bank-routing').val('');
    $('.bank-name').val('');
    $('.bank-accountType').val('-1');
  }
}
