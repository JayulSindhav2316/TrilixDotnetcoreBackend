using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Security.Cryptography;
using nb;
namespace FileEncryptDecrypt
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class frmFileEncryptDecryptMain : System.Windows.Forms.Form
	{	
		private System.Windows.Forms.TabPage tpEncrypt;
		private System.Windows.Forms.TabPage tpDecrypt;
		private System.Windows.Forms.TabControl tbcFileCryptor;
		private System.Windows.Forms.TextBox txtEncPass;
		private System.Windows.Forms.TextBox txtEncFile;
		private System.Windows.Forms.Button btnEncrypt;
		private System.Windows.Forms.Button btnDecrypt;
		private System.Windows.Forms.Button btnEncBrowse;
		private System.Windows.Forms.TextBox txtDecFile;
		private System.Windows.Forms.TextBox txtDecPass;
		private System.Windows.Forms.Button btnDecBrowse;
		private System.Windows.Forms.ProgressBar pbEncrypt;
		private System.Windows.Forms.OpenFileDialog ofdEnc;
		private System.Windows.Forms.OpenFileDialog ofdDec;
		private System.Windows.Forms.ProgressBar pbDec;
		private System.Windows.Forms.TabPage tpAbout;
		private System.Windows.Forms.Label label1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmFileEncryptDecryptMain()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.tbcFileCryptor = new System.Windows.Forms.TabControl();
			this.tpEncrypt = new System.Windows.Forms.TabPage();
			this.pbEncrypt = new System.Windows.Forms.ProgressBar();
			this.btnEncBrowse = new System.Windows.Forms.Button();
			this.btnEncrypt = new System.Windows.Forms.Button();
			this.txtEncFile = new System.Windows.Forms.TextBox();
			this.txtEncPass = new System.Windows.Forms.TextBox();
			this.tpDecrypt = new System.Windows.Forms.TabPage();
			this.pbDec = new System.Windows.Forms.ProgressBar();
			this.btnDecBrowse = new System.Windows.Forms.Button();
			this.btnDecrypt = new System.Windows.Forms.Button();
			this.txtDecFile = new System.Windows.Forms.TextBox();
			this.txtDecPass = new System.Windows.Forms.TextBox();
			this.tpAbout = new System.Windows.Forms.TabPage();
			this.ofdEnc = new System.Windows.Forms.OpenFileDialog();
			this.ofdDec = new System.Windows.Forms.OpenFileDialog();
			this.label1 = new System.Windows.Forms.Label();
			this.tbcFileCryptor.SuspendLayout();
			this.tpEncrypt.SuspendLayout();
			this.tpDecrypt.SuspendLayout();
			this.tpAbout.SuspendLayout();
			this.SuspendLayout();
			// 
			// tbcFileCryptor
			// 
			this.tbcFileCryptor.Controls.Add(this.tpEncrypt);
			this.tbcFileCryptor.Controls.Add(this.tpDecrypt);
			this.tbcFileCryptor.Controls.Add(this.tpAbout);
			this.tbcFileCryptor.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tbcFileCryptor.Location = new System.Drawing.Point(0, 0);
			this.tbcFileCryptor.Name = "tbcFileCryptor";
			this.tbcFileCryptor.SelectedIndex = 0;
			this.tbcFileCryptor.Size = new System.Drawing.Size(328, 142);
			this.tbcFileCryptor.TabIndex = 0;
			// 
			// tpEncrypt
			// 
			this.tpEncrypt.Controls.Add(this.pbEncrypt);
			this.tpEncrypt.Controls.Add(this.btnEncBrowse);
			this.tpEncrypt.Controls.Add(this.btnEncrypt);
			this.tpEncrypt.Controls.Add(this.txtEncFile);
			this.tpEncrypt.Controls.Add(this.txtEncPass);
			this.tpEncrypt.Location = new System.Drawing.Point(4, 22);
			this.tpEncrypt.Name = "tpEncrypt";
			this.tpEncrypt.Size = new System.Drawing.Size(320, 116);
			this.tpEncrypt.TabIndex = 0;
			this.tpEncrypt.Text = "Encrypt";
			// 
			// pbEncrypt
			// 
			this.pbEncrypt.Location = new System.Drawing.Point(96, 80);
			this.pbEncrypt.Name = "pbEncrypt";
			this.pbEncrypt.Size = new System.Drawing.Size(168, 23);
			this.pbEncrypt.TabIndex = 4;
			// 
			// btnEncBrowse
			// 
			this.btnEncBrowse.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnEncBrowse.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.btnEncBrowse.Location = new System.Drawing.Point(280, 80);
			this.btnEncBrowse.Name = "btnEncBrowse";
			this.btnEncBrowse.Size = new System.Drawing.Size(32, 23);
			this.btnEncBrowse.TabIndex = 3;
			this.btnEncBrowse.Text = ". . .";
			this.btnEncBrowse.Click += new System.EventHandler(this.btnEncBrowse_Click);
			// 
			// btnEncrypt
			// 
			this.btnEncrypt.Location = new System.Drawing.Point(8, 80);
			this.btnEncrypt.Name = "btnEncrypt";
			this.btnEncrypt.TabIndex = 2;
			this.btnEncrypt.Text = "Encrypt";
			this.btnEncrypt.Click += new System.EventHandler(this.btnEncrypt_Click);
			// 
			// txtEncFile
			// 
			this.txtEncFile.Location = new System.Drawing.Point(8, 40);
			this.txtEncFile.Name = "txtEncFile";
			this.txtEncFile.Size = new System.Drawing.Size(304, 20);
			this.txtEncFile.TabIndex = 1;
			this.txtEncFile.Text = "";
			// 
			// txtEncPass
			// 
			this.txtEncPass.Location = new System.Drawing.Point(8, 8);
			this.txtEncPass.Name = "txtEncPass";
			this.txtEncPass.PasswordChar = '*';
			this.txtEncPass.Size = new System.Drawing.Size(304, 20);
			this.txtEncPass.TabIndex = 0;
			this.txtEncPass.Text = "";
			// 
			// tpDecrypt
			// 
			this.tpDecrypt.Controls.Add(this.pbDec);
			this.tpDecrypt.Controls.Add(this.btnDecBrowse);
			this.tpDecrypt.Controls.Add(this.btnDecrypt);
			this.tpDecrypt.Controls.Add(this.txtDecFile);
			this.tpDecrypt.Controls.Add(this.txtDecPass);
			this.tpDecrypt.Location = new System.Drawing.Point(4, 22);
			this.tpDecrypt.Name = "tpDecrypt";
			this.tpDecrypt.Size = new System.Drawing.Size(320, 116);
			this.tpDecrypt.TabIndex = 1;
			this.tpDecrypt.Text = "Decrypt";
			// 
			// pbDec
			// 
			this.pbDec.Location = new System.Drawing.Point(96, 80);
			this.pbDec.Name = "pbDec";
			this.pbDec.Size = new System.Drawing.Size(168, 23);
			this.pbDec.TabIndex = 6;
			// 
			// btnDecBrowse
			// 
			this.btnDecBrowse.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnDecBrowse.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.btnDecBrowse.Location = new System.Drawing.Point(280, 80);
			this.btnDecBrowse.Name = "btnDecBrowse";
			this.btnDecBrowse.Size = new System.Drawing.Size(32, 23);
			this.btnDecBrowse.TabIndex = 5;
			this.btnDecBrowse.Text = ". . .";
			this.btnDecBrowse.Click += new System.EventHandler(this.btnDecBrowse_Click);
			// 
			// btnDecrypt
			// 
			this.btnDecrypt.Location = new System.Drawing.Point(8, 80);
			this.btnDecrypt.Name = "btnDecrypt";
			this.btnDecrypt.TabIndex = 4;
			this.btnDecrypt.Text = "Decrypt";
			this.btnDecrypt.Click += new System.EventHandler(this.btnDecrypt_Click);
			// 
			// txtDecFile
			// 
			this.txtDecFile.Location = new System.Drawing.Point(8, 40);
			this.txtDecFile.Name = "txtDecFile";
			this.txtDecFile.Size = new System.Drawing.Size(304, 20);
			this.txtDecFile.TabIndex = 3;
			this.txtDecFile.Text = "";
			// 
			// txtDecPass
			// 
			this.txtDecPass.Location = new System.Drawing.Point(8, 8);
			this.txtDecPass.Name = "txtDecPass";
			this.txtDecPass.PasswordChar = '*';
			this.txtDecPass.Size = new System.Drawing.Size(304, 20);
			this.txtDecPass.TabIndex = 2;
			this.txtDecPass.Text = "";
			// 
			// tpAbout
			// 
			this.tpAbout.Controls.Add(this.label1);
			this.tpAbout.Location = new System.Drawing.Point(4, 22);
			this.tpAbout.Name = "tpAbout";
			this.tpAbout.Size = new System.Drawing.Size(320, 116);
			this.tpAbout.TabIndex = 2;
			this.tpAbout.Text = "About";
			// 
			// ofdEnc
			// 
			this.ofdEnc.Filter = "All files (*.*)|*.*";
			// 
			// ofdDec
			// 
			this.ofdDec.Filter = "FileCryptor Files (*.fcfe)|*.fcfe";
			// 
			// label1
			// 
			this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.label1.Location = new System.Drawing.Point(0, 0);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(320, 116);
			this.label1.TabIndex = 0;
			this.label1.Text = "Copyright 2004 Nathan D. Blomquist";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// frmFileEncryptDecryptMain
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(328, 142);
			this.Controls.Add(this.tbcFileCryptor);
			this.MaximizeBox = false;
			this.Name = "frmFileEncryptDecryptMain";
			this.Text = "File Encrypt/Decrypt";
			this.tbcFileCryptor.ResumeLayout(false);
			this.tpEncrypt.ResumeLayout(false);
			this.tpDecrypt.ResumeLayout(false);
			this.tpAbout.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmFileEncryptDecryptMain());
		}

		private void btnEncBrowse_Click(object sender, System.EventArgs e)
		{
			if(DialogResult.OK == ofdEnc.ShowDialog())
			{
				txtEncFile.Text = ofdEnc.FileName;
			}
		}

		private void btnDecBrowse_Click(object sender, System.EventArgs e)
		{
			if(DialogResult.OK == ofdDec.ShowDialog())
			{
				txtDecFile.Text = ofdDec.FileName;
			}
		}

		private void btnEncrypt_Click(object sender, System.EventArgs e)
		{
			if(txtEncFile.Text != String.Empty &&
				File.Exists(txtEncFile.Text))
			{
				string inFile = txtEncFile.Text;
				string outFile = txtEncFile.Text + ".fcfe";
				string password = txtEncPass.Text;
				CryptoProgressCallBack cb = new CryptoProgressCallBack(this.ProgressCallBackEncrypt);

				CryptoHelp.EncryptFile(inFile,outFile,password,cb);

				pbEncrypt.Value = 0;
			}
		}

		private void btnDecrypt_Click(object sender, System.EventArgs e)
		{
			if(txtDecFile.Text != String.Empty &&
				File.Exists(txtDecFile.Text))
			{
				string inFile = txtDecFile.Text;
				int index = inFile.LastIndexOf(".fcf");
				string outFile = inFile.Substring(0,index);
				string password = txtDecPass.Text;
				CryptoProgressCallBack cb = new CryptoProgressCallBack(this.ProgressCallBackDecrypt);
				
				CryptoHelp.DecryptFile(inFile,outFile+".fcfd",password,cb);

				pbDec.Value = 0;
			}
		}

		void ProgressCallBackEncrypt(int min, int max, int value)
		{
			pbEncrypt.Minimum = min;
			pbEncrypt.Maximum = max;
			pbEncrypt.Value = value;
			Application.DoEvents();
		}

		void ProgressCallBackDecrypt(int min, int max, int value)
		{
			pbDec.Maximum = max;
			pbDec.Minimum = min;
			pbDec.Value = value;
			Application.DoEvents();
		}
	}
}
